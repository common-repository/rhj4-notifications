<div>
    <table class='rhj4_plugins_demo'>
        <tbody>
        <tr>
            <td class='rhj4_plugins_input'>Text: <input id="messageText" type="text" placeholder='Message text...'/></td>
            <td class='rhj4_plugins_comment'>Enter notification text</td>
        </tr>
        <tr>
            <td class='rhj4_plugins_input'>Type:
                <select id="messageType">
<?php
                //  Get list of currently enabled notification types
                $notif = RHJ4Notifications::instance();
                
                // Get defaults array - this defines the notification types
                $types = $notif->defaults;
                $enabled_options = get_option($notif->option_name);
                $options = "<option value='?'>[SELECT]</option>";
                foreach ($enabled_options as $key => $value) {
                    if ($key !== 'enabled') {
                        foreach ($types as $type) {
                            if ($type['option'] == $key) {
                                $match = $type;
                                break;
                            }
                        }
                        if (!empty($match)) {
                            $options .= "<option value='".$match['type']."'>".$key."</option>";
                        }
                    }
                }
                echo $options;
?>
                </select>
            </td>
            <td class='rhj4_plugins_comment'>Select notification type</td>
        </tr>
        <tr>
            <td class='rhj4_plugins_input'>Source:
                <span>Browser:<input name="messageSource" type="radio" value="browser" /></span>
                <span>Server:<input name="messageSource" type="radio" value="server" checked="checked" />
            </td>
            <td class='rhj4_plugins_comment'>Select notification source</td>
        </tr>
        <tr>	 	 
            <td class='rhj4_plugins_input'>Sticky:
                <input id="messageIsSticky" type="checkbox" /></td>	 	 
            <td class='rhj4_plugins_comment'>Check if notification should remain on screen</td></tr>	 	 
        <tr><td class='rhj4_plugins_input'>Auto-Drain:
                <input id="autoDrainQueue" type="checkbox" />
            <td class='rhj4_plugins_comment'>Check if queue should be drained immediately</td></tr>	 	
    </table>
    <table class='rhj4_plugins_buttons'>
        <tr><td>Generate Notifications: 
            <input type="button" value="Single" onclick="do_notification_submit();return false;" />
            <input type="button" value="Multiple" onclick="do_notification_submit_all();return false;" />
            <span id="queue_size"></span>
            <input id="drain" type="button" value="Drain Queue" onclick="do_notification_drain_queue();return false;"/>
            <span id='queuing' class='blink'>Queuing...</span>
        </td></tr></table>
</div>
<hr />
<div class='notification_comments'>
<p>This is a simple demonstration of some of the capabilities of the RHJ4 Notifications plugin.</p>
<p>Notifications can be generated with javascript (jQuery) code in the browser or with PHP code in the server. 
Notifications generated in the browser can be displayed immediately or queued for later display by saving them in the database.
</p>
<p>Notifications generated in the server will always be queued, and the queue will be drained and any pending notifications displayed on every page refresh.
</p>
</div>
<?php
//add_action('init', 'rhj4_plugins_demo_initialize', 1, 1);

//function rhj4_plugins_demo_initialize() {
    $args = array('enabled'     => true, 
                'output'        => 'error_log',
                'source'        => 'Notification Demo');
    //  Initialize the plugin
    $diags = RHJ4Diagnostics::instance();
    
    // Set error handler to process all errors
    error_reporting(E_ALL & ~E_STRICT & ~E_NOTICE);
    set_error_handler(array($diags,'error_handler'));
    
    //  Write the plugin name into the output stream
    rhj4_notification('RHJ4 Notifications demo loaded', NOTIFICATION_TYPE_CONFIRMATION);
//}
?>